class Asignatura:
    def __init__(self, nombre, creditos, horas, profesor):
        self.nombre = nombre
        self.creditos = creditos
        self.horas = horas
        self.profesor = profesor
