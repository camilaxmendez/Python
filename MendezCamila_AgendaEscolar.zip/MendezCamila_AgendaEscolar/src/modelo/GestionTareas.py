import os
import pickle
class GestionTareas:
    def __init__(self,usuario):
        self.tareas = []
        self.usuario = usuario

    def agregar_tarea(self, tarea):
        self.tareas.append(tarea)

    def editar_tarea(self, nombre_tarea, nuevos_datos):
        for tarea in self.tareas:
            if tarea.nombre == nombre_tarea:
                tarea.nombre = nuevos_datos.get("nombre", tarea.nombre)
                tarea.asignatura = nuevos_datos.get("asignatura", tarea.asignatura)
                tarea.fecha_entrega = nuevos_datos.get("fecha_entrega", tarea.fecha_entrega)
                tarea.prioridad = nuevos_datos.get("prioridad", tarea.prioridad)
                tarea.descripcion = nuevos_datos.get("descripcion", tarea.descripcion)
                print(f"Tarea {tarea.nombre} editada.")
                return True
        return False

    def eliminar_tarea(self, nombre_tarea):
        self.tareas = [t for t in self.tareas if t.nombre != nombre_tarea]

    def filtrar_tareas_por_semestre(self, gestion_semestres, semestre_nombre):
        return gestion_semestres.filtrar_tareas_por_semestre(self.tareas, semestre_nombre)

    def filtrar_tareas_por_mes(self, mes, anio):
        return [tarea for tarea in self.tareas if tarea.fecha_entrega.month == mes and tarea.fecha_entrega.year == anio]

    def guardar_tareas(self):
        try:
            with open(f'data/tareas_{self.usuario.username}.dat', 'wb') as file:
                pickle.dump(self.tareas, file)
        except Exception as e:
            print(f"Error al guardar datos: {e}")

    def cargar_tareas(self):
        if os.path.exists(f'data/tareas_{self.usuario.username}.dat'):
            try:
                with open(f'data/tareas_{self.usuario.username}.dat', 'rb') as file:
                    self.tareas = pickle.load(file)
            except Exception as e:
                print(f"Error al cargar datos: {e}")
        else:
            self.tareas = []