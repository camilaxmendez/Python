import os
import pickle

class GestionProfesores:
    def __init__(self, usuario):
        self.profesores = []
        self.usuario = usuario

    def agregar_profesor(self, profesor):
        if not any(p.nombre == profesor.nombre or p.cedula == profesor.cedula for p in self.profesores):
            self.profesores.append(profesor)

    def eliminar_profesor(self, nombre):
        self.profesores = [p for p in self.profesores if p.nombre != nombre]

    def editar_profesor(self, nombre, nuevos_datos):
        for profesor in self.profesores:
            if profesor.nombre == nombre:
                profesor.nombre = nuevos_datos.get("nombre", profesor.nombre)
                profesor.cedula = nuevos_datos.get("cedula", profesor.cedula)
                profesor.correo = nuevos_datos.get("correo", profesor.correo)

    def guardar_profesores(self):
        try:
            with open(f'data/profesores_{self.usuario.username}.dat', 'wb') as file:
                pickle.dump(self.profesores, file)
        except Exception as e:
            print(f"Error al guardar profesores: {e}")

    def cargar_profesores(self):
        if os.path.exists(f'data/profesores_{self.usuario.username}.dat'):
            try:
                with open(f'data/profesores_{self.usuario.username}.dat', 'rb') as file:
                    self.profesores = pickle.load(file)
            except Exception as e:
                print(f"Error al cargar profesores: {e}")
        else:
            self.profesores = []
