class HistorialTareas:
    def __init__(self, tarea_nombre, fecha_creacion, estado, prioridad):
        self.tarea_nombre = tarea_nombre
        self.fecha_creacion = fecha_creacion
        self.estado = estado
        self.prioridad = prioridad

    def __str__(self):
        return f"{self.tarea_nombre}, {self.fecha_creacion}, {self.estado}, prioridad {self.prioridad}"
