import os
import pickle
class GestionSemestres:
    def __init__(self, usuario):
        self.semestres = []
        self.usuario = usuario

    def _is_overlap(self, semestre_existente, semestre_nuevo):
        return (semestre_nuevo.fecha_inicio <= semestre_existente.fecha_fin and
                semestre_nuevo.fecha_fin >= semestre_existente.fecha_inicio)

    def agregar_semestre(self, semestre):
        if any(self._is_overlap(s, semestre) for s in self.semestres):
            raise ValueError(f"El semestre '{semestre.nombre}' se solapa con uno existente.")
        self.semestres.append(semestre)

    def obtener_semestres(self):
        return self.semestres

    def filtrar_tareas_por_semestre(self, tareas, semestre_nombre):
        semestre = next((s for s in self.semestres if s.nombre == semestre_nombre), None)
        if not semestre:
            raise ValueError(f"No se encontró el semestre '{semestre_nombre}'.")
        return list(filter(lambda t: semestre.fecha_inicio <= t.fecha_entrega <= semestre.fecha_fin, tareas))

    def filtrar_tareas_por_mes(self, tareas, mes, anio):
        return list(filter(lambda t: t.fecha_entrega.month == mes and t.fecha_entrega.year == anio, tareas))

    def guardar_semestres(self):
        try:
            with open(f'data/semestres_{self.usuario.username}.dat', 'wb') as file:
                pickle.dump(self.semestres, file)
        except Exception as e:
            print(f"Error al guardar datos semestres: {e}")

    def cargar_semestres(self):
        if os.path.exists(f'data/semestres_{self.usuario.username}.dat'):
            try:
                with open(f'data/semestres_{self.usuario.username}.dat', 'rb') as file:
                    self.semestres = pickle.load(file)
            except Exception as e:
                print(f"Error al cargar datos semestres: {e}")
        else:
            self.semestres = []

    def guardar_reporte(self, tareas, archivo="data/reportes/reporte.dat"):
        if not tareas:
            raise ValueError("No hay datos para guardar en el reporte.")
        try:
            with open(archivo, "wb") as file:
                pickle.dump(tareas, file)
        except Exception as e:
            raise IOError(f"Error al guardar el reporte: {e}")

