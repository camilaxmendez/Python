class Usuario:
    def __init__(self, username, mail, password):
        self.username = username
        self.mail = mail
        self.password = password
