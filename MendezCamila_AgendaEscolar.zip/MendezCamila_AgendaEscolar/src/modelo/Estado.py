class Estado:
    def __init__(self, nombre, descripcion=None):
        self.nombre = nombre
        self.descripcion = descripcion or ""

    def __str__(self):
        return self.nombre