class Notificacion:
    def __init__(self, destinatario, asunto, contenido):
        self.destinatario = destinatario
        self.asunto = asunto
        self.contenido = contenido

    def __str__(self):
        return f"Para: {self.destinatario}, Asunto: {self.asunto}, Contenido: {self.contenido}"
