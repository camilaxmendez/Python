import os
import pickle
class GestionAsignaturas:
    def __init__(self, usuario):
        self.asignaturas = []
        self.usuario = usuario

    def agregar_asignatura(self, asignatura):
        self.asignaturas.append(asignatura)

    def obtener_asignaturas(self):
        return self.asignaturas

    def eliminar_asignatura(self, nombre):
        self.asignaturas = [a for a in self.asignaturas if a.nombre != nombre]

    def editar_asignatura(self, nombre, nuevos_datos):
        for asignatura in self.asignaturas:
            if asignatura.nombre == nombre:
                asignatura.nombre = nuevos_datos.get("nombre", asignatura.nombre)
                asignatura.creditos = nuevos_datos.get("creditos", asignatura.creditos)
                asignatura.horas = nuevos_datos.get("horas", asignatura.horas)
                asignatura.profesor = nuevos_datos.get("profesor", asignatura.profesor)

    def guardar_asignaturas(self):
        try:
            with open(f'data/asignaturas_{self.usuario.username}.dat', 'wb') as file:
                pickle.dump(self.asignaturas, file)
        except Exception as e:
            print(f"Error al guardar datos: {e}")

    def cargar_asignaturas(self):
        if os.path.exists(f'data/asignaturas_{self.usuario.username}.dat'):
            try:
                with open(f'data/asignaturas_{self.usuario.username}.dat', 'rb') as file:
                    self.asignaturas = pickle.load(file)
            except Exception as e:
                print(f"Error al cargar datos: {e}")
        else:
            self.asignaturas = []