import pickle

from src.modelo.HistorialTareas import HistorialTareas
class GestionHistorial:
    def __init__(self):
        self.registros = []

    def agregar_registro(self, tarea_nombre, fecha_entrega, estado, prioridad):
        if not any(r.tarea_nombre == tarea_nombre for r in self.registros):
            self.registros.append(HistorialTareas(tarea_nombre, fecha_entrega, estado, prioridad))

    def actualizar_historial_estado(self, tarea):
        historial_existente = next((h for h in self.registros if h.tarea_nombre == tarea.nombre), None)
        if historial_existente:
            historial_existente.estado = tarea.estado
            historial_existente.prioridad = tarea.prioridad
        else:
            self.agregar_registro(tarea.nombre, tarea.fecha_entrega, tarea.estado, tarea.prioridad)

    def eliminar_registro_por_nombre(self, nombre_tarea):
        self.registros = [r for r in self.registros if r.tarea_nombre != nombre_tarea]

    def filtrar_por_estado(self, estado):
        return list(filter(lambda r: r.estado == estado, self.registros))

    def filtrar_por_prioridad(self, prioridad):
        return list(filter(lambda r: r.prioridad == prioridad, self.registros))

    def filtrar_por_fecha(self, fecha):
        return list(filter(lambda r: r.fecha_creacion == fecha, self.registros))

    def listar_todo(self):
        return self.registros

    def actualizar_estado_tarea(self, nombre_tarea, nuevo_estado):
        list(map(lambda r: setattr(r, 'estado', nuevo_estado) if r.tarea_nombre == nombre_tarea else None, self.registros))

    def guardar_reporte(self, tareas, archivo="data/reportes/reporte.dat"):
        if not tareas:
            raise ValueError("No hay datos para guardar en el reporte.")
        try:
            with open(archivo, "wb") as file:
                pickle.dump(tareas, file)
        except Exception as e:
            raise IOError(f"Error al guardar el reporte: {e}")