class Subtarea:
    def __init__(self, nombre, descripcion, estado="Pendiente"):
        self.nombre = nombre
        self.descripcion = descripcion
        self.estado = estado

    def __str__(self):
        return f"Subtarea: {self.nombre}, Estado: {self.estado}"
