from datetime import datetime
import smtplib
from email.mime.text import MIMEText

class GestionNotificaciones:
    def __init__(self):
        self.dias_antes = 1

    def programar_notificaciones(self, dias_antes):
        self.dias_antes = max(1, dias_antes)

    def generar_alerta_tareas_pendientes(self, gestion_tareas):
        tareas_pendientes = list(filter(lambda t: t.estado == "Pendiente", gestion_tareas.tareas))
        if not tareas_pendientes:
            return "No tiene tareas pendientes."
        return "Tareas pendientes:\n" + "\n".join(map(lambda t: f"- {t.nombre} (Entrega: {t.fecha_entrega})", tareas_pendientes))

    def enviar_notificacion_tarea(self, tarea, usuario):
        mensaje = f"Se ha creado la tarea '{tarea.nombre}'.\n" \
                  f"Fecha de entrega: {tarea.fecha_entrega}\n" \
                  f"Prioridad: {tarea.prioridad}\n" \
                  f"Descripción: {tarea.descripcion}"
        self.enviar_correo(usuario.mail, "Nueva tarea creada", mensaje)

    def generar_notificaciones_tareas(self, gestion_tareas, usuario):
        hoy = datetime.now().date()
        tareas_para_notificar = list(filter(lambda t: t.fecha_entrega and (t.fecha_entrega - hoy).days == self.dias_antes,gestion_tareas.tareas,))

        if not tareas_para_notificar:
            print("No hay tareas para notificar.")
            return
        mensaje = "Atención, tienes tareas por expirar:\n\n" + "\n".join(map(lambda t: f"- {t.nombre} , Entrega: {t.fecha_entrega}", tareas_para_notificar))
        self.enviar_correo(usuario.mail, "Recordatorio de tareas", mensaje)

    def enviar_correo(self, destinatario, asunto, mensaje):
        try:
            smtp_host = "smtp.gmail.com"
            smtp_port = 587
            remitente = "agendanotificacionesremitente@gmail.com"
            password = "ljmi lhnr yxor bssq"

            correo = MIMEText(mensaje, "plain", "utf-8")
            correo["From"] = remitente
            correo["To"] = destinatario
            correo["Subject"] = asunto

            with smtplib.SMTP(smtp_host, smtp_port) as servidor:
                servidor.starttls()
                servidor.login(remitente, password)
                servidor.sendmail(remitente, destinatario, correo.as_string())

            print(f"Correo enviado a {destinatario}")
        except Exception as e:
            print(f"Error al enviar el correo: {e}")
