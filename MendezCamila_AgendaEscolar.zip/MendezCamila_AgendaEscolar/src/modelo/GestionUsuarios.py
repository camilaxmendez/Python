import os
import pickle


class GestionUsuarios:
    def __init__(self):
        self.usuarios = []

    def agregar_usuario(self, usuario):
        if not any(u.username == usuario.username for u in self.usuarios):
            self.usuarios.append(usuario)
            return True
        return False

    def buscar_usuario(self, username):
        return next((usuario for usuario in self.usuarios if usuario.username == username), None)

    def verificar_credenciales(self, username, password, mail):
        return any(u.username == username and u.password == password and u.mail == mail for u in self.usuarios)

    def guardar_datos(self):
        try:
            with open('data/usuarios.dat', 'wb') as file:
                pickle.dump(self.usuarios, file)
        except Exception as e:
            print(f"Error al guardar datos: {e}")

    def cargar_datos(self):
        if os.path.exists('data/usuarios.dat'):
            try:
                with open('data/usuarios.dat', 'rb') as file:
                    self.usuarios = pickle.load(file)
            except Exception as e:
                print(f"Error al cargar datos: {e}")
        else:
            self.usuarios = []