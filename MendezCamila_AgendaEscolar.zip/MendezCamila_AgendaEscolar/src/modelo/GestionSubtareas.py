import os
import pickle

class GestionSubtareas:
    def __init__(self, usuario):
        self.usuario = usuario
        self.subtareas = []

    def agregar_subtarea(self, subtarea):
        self.subtareas.append(subtarea)

    def eliminar_subtarea(self, subtarea_nombre):
        self.subtareas = [s for s in self.subtareas if s.nombre != subtarea_nombre]

    def editar_subtarea(self, subtarea_nombre, nuevos_datos):
        subtarea = next((s for s in self.subtareas if s.nombre == subtarea_nombre), None)
        if subtarea:
            subtarea.nombre = nuevos_datos.get("nombre", subtarea.nombre)
            subtarea.descripcion = nuevos_datos.get("descripcion", subtarea.descripcion)
            subtarea.estado = nuevos_datos.get("estado", subtarea.estado)

    def guardar_subtareas(self):
        try:
            with open(f'data/subtareas_{self.usuario.username}.dat', 'wb') as file:
                pickle.dump(self.subtareas, file)
        except Exception as e:
            print(f"Error al guardar datos: {e}")

    def cargar_subtareas(self):
        if os.path.exists(f'data/subtareas_{self.usuario.username}.dat'):
            try:
                with open(f'data/subtareas_{self.usuario.username}.dat', 'rb') as file:
                    self.subtareas = pickle.load(file)
            except Exception as e:
                print(f"Error al cargar datos: {e}")
        else:
            self.subtareas = []
