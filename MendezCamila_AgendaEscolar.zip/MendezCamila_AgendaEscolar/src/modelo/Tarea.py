from datetime import datetime
class Tarea:
    def __init__(self, nombre, asignatura, fecha_entrega, prioridad, descripcion, estado="Pendiente"):
        self.nombre = nombre
        self.asignatura = asignatura
        if isinstance(fecha_entrega, str):
            self.fecha_entrega = datetime.strptime(fecha_entrega, "%Y-%m-%d").date()
        elif isinstance(fecha_entrega, datetime):
            self.fecha_entrega = fecha_entrega.date()
        else:
            self.fecha_entrega = fecha_entrega
        self.prioridad = prioridad
        self.descripcion = descripcion
        self.estado = estado
        self.subtareas = []  # Lista de subtareas


    def agregar_subtarea(self, subtarea):
        self.subtareas.append(subtarea)

    def actualizar_estado(self):
        if not self.subtareas:
            return
        self.estado = (
            "Completado" if all(subtarea.estado == "Completado" for subtarea in self.subtareas) else
            "En progreso" if any(subtarea.estado == "Completado" for subtarea in self.subtareas) else
            "Pendiente"
        )

    def __str__(self):
        return f"Tarea: {self.nombre}, Estado: {self.estado}, Subtareas: {len(self.subtareas)}"