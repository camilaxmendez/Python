import sys
from PyQt6 import QtWidgets
from src.controlador.ControladorAgenda import ControladorAgenda
from src.modelo.GestionUsuarios import GestionUsuarios

class Main:
    app = QtWidgets.QApplication(sys.argv)
    gestion_usuarios = GestionUsuarios()
    controlador = ControladorAgenda.VentanaLogin(usuario=None, gestion_usuarios=gestion_usuarios)
    controlador.show()
    sys.exit(app.exec())