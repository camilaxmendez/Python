import re
from PyQt6 import QtCore
from PyQt6.QtWidgets import QWidget, QMessageBox
from datetime import datetime
from src.modelo.Asignatura import Asignatura
from src.modelo.GestionAsignaturas import GestionAsignaturas
from src.modelo.GestionHistorial import GestionHistorial
from src.modelo.GestionNotificaciones import GestionNotificaciones
from src.modelo.GestionProfesores import GestionProfesores
from src.modelo.GestionSemestres import GestionSemestres
from src.modelo.GestionSubtareas import GestionSubtareas
from src.modelo.GestionTareas import GestionTareas
from src.modelo.Profesor import Profesor
from src.modelo.Semestre import Semestre
from src.modelo.Subtarea import Subtarea
from src.modelo.Tarea import Tarea
from src.modelo.Usuario import Usuario
from src.vista.Wacerca import Ui_FormAcerca
from src.vista.Wayuda import Ui_FormAyuda
from src.vista.Wlogin import Ui_LoginWindow
from src.vista.Wnotificaciones import Ui_FormNotificaciones
from src.vista.Wprofesores import Ui_FormProfesores
from src.vista.Wsubtareas import Ui_FormSubtareas
from src.vista.Wtareas import Ui_FormTareas
from src.vista.Whistorial import Ui_FormHistorial
from src.vista.Wprincipal import Ui_principalWindow
from src.vista.Wasignaturas import Ui_FormAsignaturas
from src.vista.Wsemestre import Ui_FormAgregarSemestre
from src.vista.Wgestionsemestre import Ui_FormSemestre
import sys
from PyQt6 import QtWidgets

#Clase ControladorAgenda maneja las clases de cada Ventana
class ControladorAgenda:

    # ** Ventana Login ** gestiona el ingreso y creación de un usuario
    class VentanaLogin(QtWidgets.QMainWindow, Ui_LoginWindow):
        def __init__(self, usuario, gestion_usuarios, parent=None):
            super().__init__(parent)
            self.setupUi(self)
            self.usuario = usuario
            self.gestion_usuarios = gestion_usuarios
            self.usuario = None
            self.gestion_usuarios.cargar_datos()
            self.txt_password.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password)
            self.btn_iniciar_sesion.clicked.connect(self.iniciar_sesion)
            self.btn_crear_usuario.clicked.connect(self.crear_usuario)

        # funcion que valida que el correo sea de un dominio válido
        def validar_correo(self, correo):
            patron = r'^[\w\.-]+@[\w\.-]+\.\w+$'
            return re.match(patron, correo) is not None

        # funcion para tomar datos ingresados e iniciar sesion
        def iniciar_sesion(self):
            username = self.txt_username.text().strip()
            password = self.txt_password.text().strip()
            mail = self.txt_mail.text().strip()

            # Validar correo antes de proceder
            if not self.validar_correo(mail):
                QtWidgets.QMessageBox.warning(self, "Error", "Correo inválido. Por favor, ingrese un correo válido.")
                self.txt_mail.clear()
                return

            if self.gestion_usuarios.verificar_credenciales(username, password,mail):
                print("Inicio de sesión exitoso")
                usuario = self.gestion_usuarios.buscar_usuario(username)
                self.close()
                self.usuario = usuario
                self.mostrar_ventana_principal()
            else:
                QtWidgets.QMessageBox.warning(self, "Error", "Credenciales incorrectas.")
                self.txt_username.clear()
                self.txt_password.clear()
                self.txt_mail.clear()

        # funcion para tomar datos ingresados y crear un nuevo usuario
        def crear_usuario(self):
            username = self.txt_username.text().strip()
            mail = self.txt_mail.text().strip()
            password = self.txt_password.text().strip()

            # Validar correo antes de proceder
            if not self.validar_correo(mail):
                QtWidgets.QMessageBox.warning(self, "Error", "Correo inválido. Por favor, ingrese un correo válido.")
                self.txt_mail.clear()
                return

            if not username or not mail or not password:
                QtWidgets.QMessageBox.warning(self, "Error", "Todos los campos son obligatorios.")
                return

            #Creacion del usuario
            nuevo_usuario = Usuario(username, mail, password)
            if self.gestion_usuarios.agregar_usuario(nuevo_usuario):
                self.gestion_usuarios.guardar_datos()
                self.usuario=nuevo_usuario
                QtWidgets.QMessageBox.information(self, "Éxito", "Usuario creado exitosamente.")
                self.txt_username.clear()
                self.txt_mail.clear()
                self.txt_password.clear()
            else:
                QtWidgets.QMessageBox.warning(self, "Error", "El usuario ya existe.")

        # funcion para dirigirse a la ventana principal de la agenda
        def mostrar_ventana_principal(self):
            self.ventana_principal = ControladorAgenda.VentanaPrincipal(usuario=self.usuario)
            self.ventana_principal.show()

    # **Ventana Principal** contiene todas las opciones de la agenda
    class VentanaPrincipal(QtWidgets.QMainWindow, Ui_principalWindow):
        def __init__(self,usuario, parent=None):
            super().__init__(parent)
            self.setupUi(self)
            self.usuario = usuario
            self.gestion_tareas = GestionTareas(usuario=self.usuario)
            self.gestion_asignaturas = GestionAsignaturas(usuario=self.usuario)
            self.gestion_historial = GestionHistorial()
            self.gestion_semestres = GestionSemestres(usuario=self.usuario)
            self.gestion_profesores = GestionProfesores(usuario=self.usuario)
            self.gestion_subtareas = GestionSubtareas(usuario=self.usuario)
            self.gestion_notificaciones = GestionNotificaciones()

            self.gestion_tareas.cargar_tareas()
            self.gestion_asignaturas.cargar_asignaturas()
            self.gestion_semestres.cargar_semestres()
            self.gestion_profesores.cargar_profesores()
            self.gestion_subtareas.cargar_subtareas()
            self.sincronizar_historial_con_tareas()

            self.actionAgregar_Editar_Tarea.triggered.connect(self.mostrar_ventana_tareas)
            self.actionAsignaturas.triggered.connect(self.mostrar_ventana_asignaturas)
            self.actionProfesores.triggered.connect(self.mostrar_ventana_profesores)
            self.actionSubtareas.triggered.connect(self.mostrar_ventana_subtareas)
            self.actionNotificaciones.triggered.connect(self.mostrar_ventana_notificaciones)
            self.actionHistorial_de_tareas.triggered.connect(self.mostrar_ventana_historial)
            self.actionAgregar_semestre.triggered.connect(self.mostrar_ventana_agregar_semestres)
            self.actionGestionar_Semestre.triggered.connect(self.mostrar_ventana_gestionar_semestres)
            self.actionPreguntas.triggered.connect(self.mostrar_ventana_ayuda)
            self.actionAcerca.triggered.connect(self.mostrar_ventana_acerca)
            self.toolBar.addAction(self.actionPreguntas)
            self.toolBar.addAction(self.actionAcerca)

            self.ventana_gestionar_semestre = None
            self.ventana_agregar_semestre = None
            self.btn_agregar_tarea.clicked.connect(self.agregar_tarea)
            self.btn_editar_tarea.clicked.connect(self.editar_tarea)
            self.btn_eliminar_tarea.clicked.connect(self.eliminar_tarea)
            self.actualizar_lista_tareas()
            self.mostrar_alerta_tareas_pendientes()
            self.generar_notificaciones_tareas()
            self.actualizar_historial_tareas()

        def closeEvent(self, event):
            super().closeEvent(event)
            self.gestion_tareas.guardar_tareas()
            self.gestion_asignaturas.guardar_asignaturas()
            self.gestion_profesores.guardar_profesores()
            self.gestion_semestres.guardar_semestres()
            self.gestion_subtareas.guardar_subtareas()

        # ** Funciones para mostrar cada ventana de las opciones del menu **
        def mostrar_ventana_tareas(self):
            self.ventana_tareas = ControladorAgenda.VentanaTareas(parent_window=self,usuario=self.usuario)
            self.ventana_tareas.show()

        def mostrar_ventana_subtareas(self):
            self.ventana_subtareas = ControladorAgenda.VentanaSubtareas(usuario=self.usuario, parent_window=self)
            self.ventana_subtareas.show()

        def mostrar_ventana_asignaturas(self):
            self.ventana_asignaturas = ControladorAgenda.VentanaAsignaturas(parent_window=self, usuario=self.usuario)
            self.ventana_asignaturas.show()

        def mostrar_ventana_profesores(self):
            self.ventana_profesores = ControladorAgenda.VentanaProfesores(parent_window=self, usuario=self.usuario)
            self.ventana_profesores.show()

        def mostrar_ventana_notificaciones(self):
            self.ventana_notificaciones = ControladorAgenda.VentanaNotificaciones(gestion_notificaciones=self.gestion_notificaciones)
            self.ventana_notificaciones.show()

        def mostrar_alerta_tareas_pendientes(self):
            alerta = self.gestion_notificaciones.generar_alerta_tareas_pendientes(self.gestion_tareas)
            QtWidgets.QMessageBox.information(self, "Tareas Pendientes", alerta)

        def generar_notificaciones_tareas(self):
            self.gestion_notificaciones.generar_notificaciones_tareas(self.gestion_tareas, self.usuario)

        def mostrar_ventana_historial(self):
            self.ventana_historial = ControladorAgenda.VentanaHistorial(parent_window=self)
            self.ventana_historial.show()

        def mostrar_ventana_agregar_semestres(self):
            if not self.ventana_agregar_semestre:
                self.ventana_agregar_semestre = ControladorAgenda.VentanaAgregarSemestre(parent_window=self, usuario=self.usuario)
            self.ventana_agregar_semestre.show()

        def mostrar_ventana_gestionar_semestres(self):
            if not self.ventana_gestionar_semestre:
                self.ventana_gestionar_semestre = ControladorAgenda.VentanaGestionarSemestre(parent_window=self)
            self.ventana_gestionar_semestre.actualizar_semestres()
            self.ventana_gestionar_semestre.show()

        def mostrar_ventana_ayuda(self):
            self.ventana_ayuda = QtWidgets.QWidget()
            self.ui_ayuda = Ui_FormAyuda()
            self.ui_ayuda.setupUi(self.ventana_ayuda)
            self.ventana_ayuda.setWindowModality(QtCore.Qt.WindowModality.ApplicationModal)
            self.ventana_ayuda.show()

        def mostrar_ventana_acerca(self):
            self.ventana_acerca = QtWidgets.QWidget()
            self.ui_acerca = Ui_FormAcerca()
            self.ui_acerca.setupUi(self.ventana_acerca)
            self.ventana_acerca.setWindowModality(QtCore.Qt.WindowModality.ApplicationModal)
            self.ventana_acerca.show()

        # funcion para interactuar con una tarea seleccionada en la tabla de Tareas
        def obtener_tarea_seleccionada(self):
            selected_row = self.tbl_Tareas.currentRow()
            if selected_row == -1:
                QtWidgets.QMessageBox.warning(self, "Error", "Seleccione una tarea.")
                return None
            nombre_tarea = self.tbl_Tareas.item(selected_row, 0).text()
            return next((t for t in self.gestion_tareas.tareas if t.nombre == nombre_tarea), None)

        def sincronizar_historial_con_tareas(self):
            for tarea in self.gestion_tareas.tareas:
                self.gestion_historial.actualizar_historial_estado(tarea)

        # funciones para agregar, editar y eliminar tareas directamente escogidas desde la tabla Tareas
        def agregar_tarea(self):
            self.ventana_tareas = ControladorAgenda.VentanaTareas(parent_window=self,usuario=self.usuario)
            self.ventana_tareas.show()

        def editar_tarea(self):
            tarea_seleccionada = self.obtener_tarea_seleccionada()
            if tarea_seleccionada:
                self.ventana_tareas = ControladorAgenda.VentanaTareas(
                    tarea=tarea_seleccionada, parent_window=self, usuario=self.usuario
                )
                self.ventana_tareas.show()

        def eliminar_tarea(self):
            tarea_seleccionada = self.obtener_tarea_seleccionada()
            if tarea_seleccionada:
                self.gestion_tareas.eliminar_tarea(tarea_seleccionada.nombre)
                self.gestion_tareas.guardar_tareas()
                self.gestion_historial.eliminar_registro_por_nombre(tarea_seleccionada.nombre)
                self.actualizar_lista_tareas()

        # funcion para mostrar las tareas agregadas, en la tabla Tareas
        def actualizar_lista_tareas(self):
            self.tbl_Tareas.setRowCount(0)
            for tarea in self.gestion_tareas.tareas:
                row_position = self.tbl_Tareas.rowCount()
                self.tbl_Tareas.insertRow(row_position)
                nombre_item = QtWidgets.QTableWidgetItem(tarea.nombre)
                nombre_item.setTextAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
                asignatura_item = QtWidgets.QTableWidgetItem(tarea.asignatura)
                asignatura_item.setTextAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
                fecha_entrega_item = QtWidgets.QTableWidgetItem(tarea.fecha_entrega.strftime("%Y-%m-%d"))
                fecha_entrega_item.setTextAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
                prioridad_item = QtWidgets.QTableWidgetItem(tarea.prioridad)
                prioridad_item.setTextAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
                descripcion_item = QtWidgets.QTableWidgetItem(tarea.descripcion)
                descripcion_item.setTextAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)

                self.tbl_Tareas.setItem(row_position, 0, nombre_item)
                self.tbl_Tareas.setItem(row_position, 1, asignatura_item)
                self.tbl_Tareas.setItem(row_position, 2, fecha_entrega_item)
                self.tbl_Tareas.setItem(row_position, 3, prioridad_item)
                self.tbl_Tareas.setItem(row_position, 4, descripcion_item)

        # funciones para actualizar datos de las tareas, profesores y asignaturas en las ventanas
        def actualizar_asignaturas_en_tareas(self):
            if hasattr(self, "ventana_tareas"):
                self.ventana_tareas.actualizar_asignaturas()

        def actualizar_profesores_en_asignaturas(self):
            if hasattr(self, "ventana_asignaturas"):
                self.ventana_asignaturas.actualizar_profesores()

        def actualizar_asignaturas_en_semestres(self):
            #actualiza las asignaturas en el ComboBox de la ventana Gestionar Semestres.
            if not self.ventana_gestionar_semestre:
                self.ventana_gestionar_semestre = ControladorAgenda.VentanaGestionarSemestre(parent_window=self)
            self.ventana_gestionar_semestre.actualizar_combo_asignaturas()

        def actualizar_historial_tareas(self):
            if hasattr(self, "ventana_historial"):
                self.ventana_historial.actualizar_lista_historial()

        def salir(self):
            sys.exit(0)

    # **Ventana Tareas** permite el ingreso de la informacion de una tarea
    class VentanaTareas(QtWidgets.QWidget, Ui_FormTareas):
        def __init__(self, usuario, tarea=None, parent=None, parent_window=None, fecha_entrega=None):
            super().__init__(parent)
            self.setupUi(self)
            self.parent_window = parent_window
            self.tarea = tarea
            self.usuario = usuario
            self.det_fecha_entrega.setCalendarPopup(True)
            self.det_fecha_entrega.setDate(QtCore.QDate.currentDate())
            self.cbx_prioridad.addItems(["Alta", "Media", "Baja"])
            self.actualizar_asignaturas()  #actualiza la lista de asignaturas disponibles.

            #gestores relacionados con asignaturas, tareas y historial
            self.gestion_asignaturas = GestionAsignaturas(usuario=None)
            self.gestion_tareas = GestionTareas(usuario=None)
            self.gestion_historial = GestionHistorial()

            if fecha_entrega:
                self.det_fecha_entrega.setDate(QtCore.QDate.fromString(fecha_entrega, "yyyy-MM-dd"))

            if self.tarea:
                #rellenamos los campos con los datos de la tarea seleccionada
                self.txt_nombre_tarea.setText(self.tarea.nombre)
                self.cbx_asignatura.setCurrentText(self.tarea.asignatura)
                self.det_fecha_entrega.setDate(QtCore.QDate.fromString(self.tarea.fecha_entrega.isoformat(), "yyyy-MM-dd"))
                self.cbx_prioridad.setCurrentText(self.tarea.prioridad)
                self.rtxt_descrip_tarea.setPlainText(self.tarea.descripcion)

                if not hasattr(self.tarea, "subtareas"):
                    self.tarea.subtareas = []

            self.btn_guardar_tarea.clicked.connect(self.guardar_tarea)
            self.btn_cancelar.clicked.connect(self.close)

        #funcion para actualizar la lista de asignaturas disponibles en el combo box
        def actualizar_asignaturas(self):
            self.cbx_asignatura.clear()
            if self.parent_window: #obtenemos las asignaturas desde el gestor de la ventana principal
                asignaturas = self.parent_window.gestion_asignaturas.asignaturas
                self.cbx_asignatura.addItems([a.nombre for a in asignaturas])

        #funcion para guardar los datos de la tarea, creando una nueva o editando una existente
        def guardar_tarea(self):
            nombre_tarea = self.txt_nombre_tarea.text().strip()
            asignatura = self.cbx_asignatura.currentText()
            fecha_entrega = self.det_fecha_entrega.date().toPyDate()
            prioridad = self.cbx_prioridad.currentText()
            descripcion = self.rtxt_descrip_tarea.toPlainText().strip()

            if not nombre_tarea or not asignatura:
                QtWidgets.QMessageBox.warning(self, "Error", "El nombre de la tarea y la asignatura son obligatorios.")
                return

            nuevos_datos = {"nombre": nombre_tarea,"asignatura": asignatura,"fecha_entrega": fecha_entrega,"prioridad": prioridad,"descripcion": descripcion,}

            if self.tarea: #edita una tarea existente
                editada = self.parent_window.gestion_tareas.editar_tarea(self.tarea.nombre, nuevos_datos)
                if not editada:
                    QtWidgets.QMessageBox.warning(self, "Error", "No se pudo editar la tarea seleccionada.")
                    return
            else:
                #crea una nueva tarea
                nueva_tarea = Tarea(nombre_tarea, asignatura, fecha_entrega, prioridad, descripcion)
                self.parent_window.gestion_tareas.agregar_tarea(nueva_tarea)
                self.parent_window.gestion_historial.agregar_registro(nueva_tarea.nombre, nueva_tarea.fecha_entrega, nueva_tarea.estado, nueva_tarea.prioridad)
                self.parent_window.gestion_notificaciones.enviar_notificacion_tarea(nueva_tarea, self.usuario)

            #guardamos los cambios en el gestor de tareas
            self.parent_window.gestion_tareas.guardar_tareas()
            self.parent_window.actualizar_lista_tareas()
            self.close()

    # **Ventana Subtareas** gestiona subtareas asociadas a una tarea principal
    class VentanaSubtareas(QtWidgets.QWidget, Ui_FormSubtareas):
        def __init__(self, usuario, parent_window=None, tarea=None):
            super().__init__()
            self.setupUi(self)
            self.usuario = usuario
            self.parent_window = parent_window
            self.tarea_principal = tarea  #tarea principal creada previamente
            self.gestion_subtareas = self.parent_window.gestion_subtareas
            self.gestion_tareas = self.parent_window.gestion_tareas
            self.cbx_estado_subtarea.addItems(["Pendiente", "Completado"])
            self.cargar_tareas_en_cbx()

            self.btn_agregar_subtarea.clicked.connect(self.agregar_subtarea)
            self.btn_editar_subtarea.clicked.connect(self.editar_subtarea)
            self.btn_eliminar_subtarea.clicked.connect(self.eliminar_subtarea)
            self.cbx_tarea_principal.currentIndexChanged.connect(self.actualizar_tarea_principal)
            self.lst_Subtareas.itemClicked.connect(self.seleccionar_subtarea)

            self.actualizar_lista_subtareas()

        #funcion para actualizar la tarea principal en el combo box y la lista de subtareas
        def actualizar_tarea_principal(self):
            self.tarea_principal = self.cbx_tarea_principal.currentData()
            self.actualizar_lista_subtareas()

        #funcion para  cargar los datos de la subtarea seleccionada
        def seleccionar_subtarea(self, item):
            subtarea_nombre = item.text().split(" - ")[0]
            subtarea = next((s for s in self.tarea_principal.subtareas if s.nombre == subtarea_nombre), None)

            if subtarea:
                self.txt_nombre_subtarea.setText(subtarea.nombre)
                self.rtxt_descrip_subtarea.setPlainText(subtarea.descripcion)
                self.cbx_estado_subtarea.setCurrentText(subtarea.estado)
            else:
                QtWidgets.QMessageBox.warning(self, "Error", "No se pudo encontrar la subtarea seleccionada.")

        #funcion para refrescar la lista de subtareas mostradas de la tarea principal
        def actualizar_lista_subtareas(self):
            self.lst_Subtareas.clear()
            if self.tarea_principal:
                for subtarea in self.tarea_principal.subtareas:
                    self.lst_Subtareas.addItem(f"{subtarea.nombre} - {subtarea.estado}")
            else:
                self.lst_Subtareas.addItem("No hay subtareas para mostrar.")

        #funcion para cargar todas las tareas disponibles en el combo box
        def cargar_tareas_en_cbx(self):
            self.cbx_tarea_principal.clear()
            for tarea in self.gestion_tareas.tareas:
                self.cbx_tarea_principal.addItem(tarea.nombre, tarea)

            if not self.tarea_principal and self.gestion_tareas.tareas:
                self.tarea_principal = self.gestion_tareas.tareas[0]

            if self.tarea_principal:
                index = self.cbx_tarea_principal.findText(self.tarea_principal.nombre)
                if index != -1:
                    self.cbx_tarea_principal.setCurrentIndex(index)

        #funcion para agregar una nueva subtarea a la tarea principal seleccionada
        def agregar_subtarea(self):
            nombre = self.txt_nombre_subtarea.text().strip()
            descripcion = self.rtxt_descrip_subtarea.toPlainText().strip()

            if not nombre or not descripcion: #campos obligatorios
                QtWidgets.QMessageBox.warning(self, "Error", "El nombre y la descripción son obligatorios.")
                return

            #creamos y añadimos la subtarea
            subtarea = Subtarea(nombre, descripcion)
            self.gestion_subtareas.agregar_subtarea(subtarea)
            self.tarea_principal.agregar_subtarea(subtarea)

            #actualizamos los datos en las otras ventanas
            self.tarea_principal.actualizar_estado()
            self.gestion_subtareas.guardar_subtareas()
            self.parent_window.actualizar_lista_tareas()
            self.actualizar_lista_subtareas()
            QtWidgets.QMessageBox.information(self, "Éxito", f"Subtarea '{nombre}' agregada correctamente.")

        #funcion para editar los datos de una subtarea seleccionada
        def editar_subtarea(self):
            item_seleccionado = self.lst_Subtareas.currentItem()

            if not item_seleccionado:
                QtWidgets.QMessageBox.warning(self, "Error", "Debe seleccionar una subtarea para editar.")
                return

            subtarea_nombre_original = item_seleccionado.text().split(" - ")[0]
            subtarea = next((s for s in self.tarea_principal.subtareas if s.nombre == subtarea_nombre_original), None)

            if not subtarea:
                QtWidgets.QMessageBox.warning(self, "Error", "No se pudo encontrar la subtarea seleccionada.")
                return

            #nuevos valores ingresados
            nombre_nuevo = self.txt_nombre_subtarea.text().strip()
            descripcion_nueva = self.rtxt_descrip_subtarea.toPlainText().strip()
            estado_nuevo = self.cbx_estado_subtarea.currentText()

            if not nombre_nuevo or not descripcion_nueva:
                QtWidgets.QMessageBox.warning(self, "Error", "El nombre y la descripción son obligatorios.")
                return

            #actualizamos la subtarea
            self.gestion_subtareas.editar_subtarea(subtarea.nombre, {"nombre": nombre_nuevo, "descripcion": descripcion_nueva, "estado": estado_nuevo})
            subtarea.nombre = nombre_nuevo
            subtarea.descripcion = descripcion_nueva
            subtarea.estado = estado_nuevo

            #actualizamos los datos en las otras ventanas
            self.tarea_principal.actualizar_estado()
            self.gestion_subtareas.guardar_subtareas()
            self.parent_window.actualizar_lista_tareas()
            self.parent_window.gestion_historial.actualizar_estado_tarea(self.tarea_principal.nombre, self.tarea_principal.estado)
            self.parent_window.actualizar_historial_tareas()
            self.actualizar_lista_subtareas()

            QtWidgets.QMessageBox.information(self, "Éxito", f"Subtarea '{nombre_nuevo}' actualizada correctamente.")

        #funcion para eliminar la subtarea seleccionada
        def eliminar_subtarea(self):
            item_seleccionado = self.lst_Subtareas.currentItem()

            if not item_seleccionado:
                QtWidgets.QMessageBox.warning(self, "Error", "Debe seleccionar una subtarea para eliminar.")
                return

            subtarea_nombre = item_seleccionado.text().split(" - ")[0]
            subtarea = next((s for s in self.tarea_principal.subtareas if s.nombre == subtarea_nombre), None)

            if not subtarea:
                QtWidgets.QMessageBox.warning(self, "Error", "No se pudo encontrar la subtarea seleccionada.")
                return

            #llamamos al gestor para eliminar la subtarea
            self.gestion_subtareas.eliminar_subtarea(subtarea_nombre)
            self.tarea_principal.subtareas.remove(subtarea)

            #actualizamos datos en las otras ventanas
            self.tarea_principal.actualizar_estado()
            self.gestion_subtareas.guardar_subtareas()
            self.parent_window.gestion_historial.actualizar_estado_tarea(self.tarea_principal.nombre, self.tarea_principal.estado)
            self.parent_window.actualizar_historial_tareas()
            self.parent_window.actualizar_lista_tareas()
            self.actualizar_lista_subtareas()
            self.limpiar_campos()

            QtWidgets.QMessageBox.information(self, "Éxito", f"Subtarea '{subtarea_nombre}' eliminada correctamente.")

        def limpiar_campos(self):
            self.txt_nombre_subtarea.clear()
            self.rtxt_descrip_subtarea.clear()

    # **Ventana Profesores** gestiona la agregacion, edicion y eliminacion de un profesor
    class VentanaProfesores(QtWidgets.QWidget, Ui_FormProfesores):
        def __init__(self, usuario, parent_window=None, parent=None):
            super().__init__(parent)
            self.setupUi(self)
            self.usuario = usuario
            self.parent_window = parent_window
            self.gestion_profesores = self.parent_window.gestion_profesores

            self.btn_agregar_profesor.clicked.connect(self.agregar_profesor)
            self.btn_editar_profesor.clicked.connect(self.guardar_cambios_profesor)
            self.btn_eliminar_profesor.clicked.connect(self.eliminar_profesor)
            self.lst_Profesor.itemClicked.connect(self.preparar_edicion_profesor)

            self.profesor_en_edicion = None
            self.actualizar_lista_profesores()

        #funcion para validar la cedula del profesor
        def validar_cedula(self, cedula):
            if len(cedula) != 10 or not cedula.isdigit():
                return False
            digitos = list(map(int, cedula))
            coeficientes = [2, 1] * 4 + [2]
            suma = sum(d * c if d * c < 10 else d * c - 9 for d, c in zip(digitos[:-1], coeficientes))
            digito_verificador = (10 - suma % 10) % 10
            return digito_verificador == digitos[-1]

        #funcion para agregar un profesor después de validar los datos ingresados
        def agregar_profesor(self):
            nombre = self.txt_nombre_profesor.text().strip()
            cedula = self.txt_cedula.text().strip()
            correo = self.txt_correo_profesor.text().strip()

            #campos obligatorios
            if not nombre or not cedula or not correo:
                QtWidgets.QMessageBox.warning(self, "Error", "Todos los campos son obligatorios.")
                return

            #validar cedula
            if not self.validar_cedula(cedula):
                QtWidgets.QMessageBox.warning(self, "Error", "La cédula ingresada no es válida.")
                return

            #validar que no existan cedulas duplicadas
            if any(p.cedula == cedula for p in self.gestion_profesores.profesores):
                QtWidgets.QMessageBox.warning(self, "Error", "Ya existe un profesor con esta cédula.")
                return

            #creamos y agregamos al profesor
            nuevo_profesor = Profesor(nombre, cedula, correo)
            self.gestion_profesores.agregar_profesor(nuevo_profesor)
            self.gestion_profesores.guardar_profesores()
            self.actualizar_lista_profesores()
            self.limpiar_campos()

            #actualizamos los profesores en la ventana de asignaturas
            if self.parent_window:
                self.parent_window.actualizar_profesores_en_asignaturas()

        #funcion para cargar los datos de un profesor seleccionado para editarlo
        def preparar_edicion_profesor(self, item):
            nombre_profesor = item.text()
            profesor = next((p for p in self.gestion_profesores.profesores if p.nombre == nombre_profesor), None)

            if profesor:
                self.txt_nombre_profesor.setText(profesor.nombre)
                self.txt_cedula.setText(profesor.cedula)
                self.txt_correo_profesor.setText(profesor.correo)
                self.profesor_en_edicion = profesor

        #funcion para guardar los datos del profesor seleccionado
        def guardar_cambios_profesor(self):
            if not self.profesor_en_edicion:
                QtWidgets.QMessageBox.warning(self, "Error", "Seleccione un profesor para editar.")
                return

            nombre = self.txt_nombre_profesor.text().strip()
            cedula = self.txt_cedula.text().strip()
            correo = self.txt_correo_profesor.text().strip()

            if not nombre or not cedula or not correo:
                QtWidgets.QMessageBox.warning(self, "Error", "Todos los campos son obligatorios.")
                return

            if not self.validar_cedula(cedula):
                QtWidgets.QMessageBox.warning(self, "Error", "La cédula ingresada no es válida.")
                return

            #actualizamos los datos del profesor en edición
            self.profesor_en_edicion.nombre = nombre
            self.profesor_en_edicion.cedula = cedula
            self.profesor_en_edicion.correo = correo

            self.gestion_profesores.guardar_profesores()
            self.actualizar_lista_profesores()
            self.limpiar_campos()

            if self.parent_window:
                self.parent_window.actualizar_profesores_en_asignaturas()
            self.profesor_en_edicion = None

        #funcion para eliminar un profesor seleccionado
        def eliminar_profesor(self):
            item_seleccionado = self.lst_Profesor.currentItem()
            if not item_seleccionado:
                QtWidgets.QMessageBox.warning(self, "Error", "Seleccione un profesor para eliminar.")
                return

            nombre_profesor = item_seleccionado.text()
            self.gestion_profesores.eliminar_profesor(nombre_profesor)
            self.gestion_profesores.guardar_profesores()
            self.actualizar_lista_profesores()
            self.limpiar_campos()

            #actualizamos la lista de profesores en asignaturas
            if self.parent_window:
                self.parent_window.actualizar_profesores_en_asignaturas()

        #funcion para vaciar los datos de entrada
        def limpiar_campos(self):
            self.txt_nombre_profesor.clear()
            self.txt_cedula.clear()
            self.txt_correo_profesor.clear()
            self.profesor_en_edicion = None

        #funcion para actualizar la lista de profesores mostrados en la lista
        def actualizar_lista_profesores(self):
            self.lst_Profesor.clear()
            for profesor in self.gestion_profesores.profesores:
                self.lst_Profesor.addItem(profesor.nombre)

    # **Ventana Asignaturas** gestiona la creacion, edicion o eliminacion de una asignatura
    class VentanaAsignaturas(QtWidgets.QWidget, Ui_FormAsignaturas):
        def __init__(self, usuario,parent_window=None, parent=None):
            super().__init__(parent)
            self.setupUi(self)
            self.usuario = usuario
            self.parent_window = parent_window
            self.gestion_asignaturas = self.parent_window.gestion_asignaturas
            self.gestion_profesores = self.parent_window.gestion_profesores
            self.gestion_semestres = self.parent_window.gestion_semestres

            self.btn_agregar_asignatura.clicked.connect(self.agregar_asignatura)
            self.btn_editar_asignatura.clicked.connect(self.guardar_cambios_asignatura)
            self.btn_eliminar_asignatura.clicked.connect(self.eliminar_asignatura)
            self.lst_Asignaturas.itemClicked.connect(self.preparar_edicion_asignatura)
            self.asignatura_editando = None
            self.actualizar_lista_asignaturas()
            self.actualizar_profesores()

        #funcion para agregar una nueva asignatura a la lista después de validar los datos
        def agregar_asignatura(self):
            nombre = self.txt_nombre_asignatura.text().strip()
            creditos = self.txt_creditos.text().strip()
            horas = self.txt_horas.text().strip()
            profesor = self.cbx_profesor.currentText()

            #campos obligatorios
            if not nombre or not creditos or not horas or not profesor:
                QtWidgets.QMessageBox.warning(self, "Error", "Todos los campos son obligatorios.")
                return
            try: #validar tipos de datos
                creditos = int(creditos)
                horas = int(horas)
            except ValueError:
                QtWidgets.QMessageBox.warning(self, "Error", "Créditos y horas deben ser números enteros.")
                return
            #validar que no existan asignaturas duplicadas
            if next((a for a in self.gestion_asignaturas.asignaturas if a.nombre == nombre), None):
                QtWidgets.QMessageBox.warning(self, "Error", "La asignatura ya existe.")
                return

            #creamos y guardamos la asignatura
            nueva_asignatura = Asignatura(nombre, creditos, horas, profesor)
            print(f"Asignatura creada: {nueva_asignatura}")
            self.gestion_asignaturas.agregar_asignatura(nueva_asignatura)
            self.gestion_asignaturas.guardar_asignaturas()
            print("Asignatura guardada exitosamente")
            self.actualizar_lista_asignaturas()
            self.limpiar_campos()

            #actualizamos las asignaturas en la ventana de tareas
            if self.parent_window:
                try:
                    self.parent_window.actualizar_asignaturas_en_tareas()
                    self.parent_window.actualizar_asignaturas_en_semestres()
                except AttributeError as e:
                    print(f"Error al actualizar ventanas relacionadas: {e}")

        #funcion para preparar la edicion de una asigntura
        def preparar_edicion_asignatura(self, item):
            nombre_asignatura = item.text()
            asignatura = next((a for a in self.gestion_asignaturas.asignaturas if a.nombre == nombre_asignatura), None)

            #mostramos los datos previamente ingresados de la asignatura seleccionada
            if asignatura:
                self.txt_nombre_asignatura.setText(asignatura.nombre)
                self.txt_creditos.setText(str(asignatura.creditos))
                self.txt_horas.setText(str(asignatura.horas))
                self.cbx_profesor.setCurrentText(asignatura.profesor)
                self.asignatura_editando = asignatura

        #funcion para guardar los cambios de la asignatura en edicion
        def guardar_cambios_asignatura(self):
            if not self.asignatura_editando:
                QtWidgets.QMessageBox.warning(self, "Error", "No se ha seleccionado ninguna asignatura para editar.")
                return

            nombre = self.txt_nombre_asignatura.text().strip()
            creditos = self.txt_creditos.text().strip()
            horas = self.txt_horas.text().strip()
            profesor = self.cbx_profesor.currentText()

            if not nombre or not creditos or not horas or not profesor:
                QtWidgets.QMessageBox.warning(self, "Error", "Todos los campos son obligatorios.")
                return

            #actualizamos los datos de la asignatura
            try:
                self.asignatura_editando.nombre = nombre
                self.asignatura_editando.creditos = int(creditos)
                self.asignatura_editando.horas = int(horas)
                self.asignatura_editando.profesor = profesor
            except ValueError:
                QtWidgets.QMessageBox.warning(self, "Error", "Créditos y horas deben ser números enteros.")
                return

            #guardamos los cambios y actualizamos la lista
            self.gestion_asignaturas.guardar_asignaturas()
            self.actualizar_lista_asignaturas()
            self.limpiar_campos()

            #actualizamos asignatuas en ventana tareas
            if self.parent_window:
                self.parent_window.actualizar_asignaturas_en_tareas()
                self.parent_window.actualizar_asignaturas_en_semestres()
            self.asignatura_editando = None

        #funcion para eliminar asignatura seleccionada
        def eliminar_asignatura(self):
            item_seleccionado = self.lst_Asignaturas.currentItem()

            if item_seleccionado:
                nombre = item_seleccionado.text()
                self.gestion_asignaturas.eliminar_asignatura(nombre)
                self.gestion_asignaturas.guardar_asignaturas()
                self.actualizar_lista_asignaturas()
                self.limpiar_campos()
                if self.parent_window:
                    self.parent_window.actualizar_asignaturas_en_tareas()
                    self.parent_window.actualizar_asignaturas_en_semestres()
            else:
                QtWidgets.QMessageBox.warning(self, "Error", "Seleccione una asignatura para eliminar.")

        #funcion para limpiar los campos de ingreso de datos
        def limpiar_campos(self):
            self.txt_nombre_asignatura.clear()
            self.txt_creditos.clear()
            self.txt_horas.clear()
            self.cbx_profesor.setCurrentIndex(0)
            self.asignatura_editando = None

        #funcion para actualizar los datos mostrados en la lista asignaturas
        def actualizar_lista_asignaturas(self):
            self.lst_Asignaturas.clear()
            for asignatura in self.gestion_asignaturas.asignaturas:
                self.lst_Asignaturas.addItem(asignatura.nombre)

        #funcion para actualizar el combo box de profesores con la lista de los ingresado en ventana profesores
        def actualizar_profesores(self):
            self.cbx_profesor.clear()
            for profesor in self.gestion_profesores.profesores:
                self.cbx_profesor.addItem(profesor.nombre)

    # **Ventana Historial de Tareas** muestra reportes basados en un criterio de filtrado de tareas y guarda reportes en .dat
    class VentanaHistorial(QtWidgets.QWidget, Ui_FormHistorial):
        def __init__(self, parent=None,parent_window=None):
            super().__init__(parent)
            self.setupUi(self)
            self.parent_window = parent_window
            self.det_filtrar_fecha.setCalendarPopup(True)
            self.det_filtrar_fecha.setDate(QtCore.QDate.currentDate())
            self.gestion_historial = self.parent_window.gestion_historial
            self.gestion_tareas = GestionTareas(usuario=None)
            self.btn_filtrar_fecha.clicked.connect(self.filtrar_fecha)
            self.btn_filtrar_estado.clicked.connect(self.filtrar_estado)
            self.btn_filtrar_prioridad.clicked.connect(self.filtrar_prioridad)
            self.btn_guardar_reporte.clicked.connect(self.guardar_reporte)

            self.cbx_filtrar_estado.addItem("")
            self.cbx_filtrar_estado.addItem("Pendiente")
            self.cbx_filtrar_estado.addItem("En progreso")
            self.cbx_filtrar_estado.addItem("Completado")
            self.cbx_filtrar_prioridad.addItem("")
            self.cbx_filtrar_prioridad.addItem("Alta")
            self.cbx_filtrar_prioridad.addItem("Media")
            self.cbx_filtrar_prioridad.addItem("Baja")

            self.actualizar_lista_historial()

        #funcion para actualizar la lista de historial en función de las tareas existentes
        def actualizar_lista_historial(self):
            """Sincroniza y muestra todas las tareas en el historial."""
            self.gestion_historial.registros = []
            for tarea in self.parent_window.gestion_tareas.tareas:
                self.gestion_historial.actualizar_historial_estado(tarea)

            self.lst_Historial.clear()
            for historial in self.gestion_historial.listar_todo():
                self.lst_Historial.addItem(str(historial))

        #funcion para mostrar un reporte de tareas por fecha seleccionada del calendario
        def filtrar_fecha(self):
            fecha_seleccionada = self.det_filtrar_fecha.date()
            if fecha_seleccionada.isValid():
                fecha_seleccionada= self.det_filtrar_fecha.date().toPyDate()
                filtrado = self.parent_window.gestion_historial.filtrar_por_fecha(fecha_seleccionada)
                self.mostrar_resultados_filtrados(filtrado)
            else:
                QtWidgets.QMessageBox.warning(self, "Error", "Por favor, seleccione una fecha válida.")

        #funcion para mostrar un reporte de tareas por su estado
        def filtrar_estado(self):
            estado_seleccionado = self.cbx_filtrar_estado.currentText()
            if estado_seleccionado:
                filtrado = self.parent_window.gestion_historial.filtrar_por_estado(estado_seleccionado)
                self.mostrar_resultados_filtrados(filtrado)

        #funcion para mostrar un reporte de tareas por su prioridad
        def filtrar_prioridad(self):
            prioridad_seleccionada = self.cbx_filtrar_prioridad.currentText()
            if prioridad_seleccionada:
                filtrado = self.parent_window.gestion_historial.filtrar_por_prioridad(prioridad_seleccionada)
                self.mostrar_resultados_filtrados(filtrado)

        #funcion para mostrar los resultados filtrados en la lista de historial
        def mostrar_resultados_filtrados(self, filtrado):
            self.lst_Historial.clear()
            if filtrado:
                for historial in filtrado:
                    self.lst_Historial.addItem(str(historial))
            else:
                self.lst_Historial.addItem("No se encontraron resultados.")

        #funcion para guardar el reporte de las tareas filtradas en un archivo .dat
        def guardar_reporte(self):
            tareas = [self.lst_Historial.item(i).text() for i in range(self.lst_Historial.count())]

            if not tareas:
                QtWidgets.QMessageBox.warning(self, "Error", "No hay datos para guardar en el reporte.")
                return
            try:
                self.parent_window.gestion_semestres.guardar_reporte(tareas)
                QtWidgets.QMessageBox.information(self, "Éxito", "Reporte guardado en carpeta reportes")
            except Exception as e:
                QtWidgets.QMessageBox.warning(self, "Error", str(e))

    # **Ventana AgregarSemestre** permite agregar un semestre en un rango de fechas elegido por el usuario
    class VentanaAgregarSemestre(QWidget, Ui_FormAgregarSemestre):
        def __init__(self, usuario,parent_window=None):
            super().__init__()
            self.setupUi(self)
            self.usuario = usuario
            self.parent_window = parent_window
            self.btn_guardar_semestre.clicked.connect(self.guardar_semestre)
            self.btn_cancelar_semestre.clicked.connect(self.close)
            self.gestion_semestres = GestionSemestres(usuario=self.usuario)
            self.det_f_inicio.setDate(QtCore.QDate.currentDate())
            self.det_f_fin.setDate(QtCore.QDate.currentDate())

        #funcion para validar los datos ingresados y crear un nuevo semestre
        def guardar_semestre(self):
            try:
                nombre_semestre = self.txt_nombre_semestre.text().strip()
                fecha_inicio = self.det_f_inicio.date().toPyDate()
                fecha_fin = self.det_f_fin.date().toPyDate()

                #validar que no hayan campos vacios
                if not nombre_semestre or not fecha_inicio or not fecha_fin:
                    QMessageBox.warning(self, "Error", "Todos los campos son obligatorios.")
                    return

                #validar que la fecha de inicio sea anterior a la de fin de semestre
                if fecha_inicio >= fecha_fin:
                    QMessageBox.warning(self, "Error", "La fecha de inicio debe ser anterior a la fecha de fin.")
                    return

                #creamos y guardamos los cambios del nuevo semestre
                semestre = Semestre(nombre_semestre, fecha_inicio, fecha_fin)
                self.parent_window.gestion_semestres.agregar_semestre(semestre)
                self.gestion_semestres.guardar_semestres()
                QMessageBox.information(self, "Éxito", f"Semestre '{nombre_semestre}' agregado correctamente.")
                self.close()
            except Exception as e:
                QMessageBox.critical(self, "Error crítico", f"Ocurrió un error inesperado: {e}")

    # **Ventana GestionarSemestres** muestra reportes basados en un criterio de filtrado de semestres, meses, asignaturas y guarda reportes en .dat
    class VentanaGestionarSemestre(QtWidgets.QWidget, Ui_FormSemestre):
        def __init__(self, parent_window=None):
            super().__init__()
            self.setupUi(self)
            self.parent_window = parent_window
            self.gestion_asignaturas = self.parent_window.gestion_asignaturas
            self.btn_filtra_semestre.clicked.connect(self.filtrar_por_semestre)
            self.btn_filtra_mes.clicked.connect(self.filtrar_por_mes)
            self.btn_filtra_asignatura.clicked.connect(self.filtrar_por_asignatura)
            self.btn_guardar_reporte.clicked.connect(self.guardar_reporte)

            self.actualizar_semestres()
            self.actualizar_combo_mes()
            self.actualizar_combo_asignaturas()

        #funcion para llenar el combo box con los nombres de los semestres ingresados en ventana semestres
        def actualizar_semestres(self):
            self.cbx_filtrar_semestre.clear()
            if self.parent_window:
                semestres = self.parent_window.gestion_semestres.obtener_semestres()
                self.cbx_filtrar_semestre.addItems([s.nombre for s in semestres])

        #funcion para llenar el combo box con los meses del año para filtrar
        def actualizar_combo_mes(self):
            self.cbx_filtrar_mes.clear()
            self.meses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
                             "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]
            self.cbx_filtrar_mes.addItems(self.meses)

        #funcion para llenar el combo box con los nombres de las asignaturas ingresadas en ventana asignaturas
        def actualizar_combo_asignaturas(self):
            self.cbx_filtrar_asignatura.clear()
            if self.parent_window:
                asignaturas = self.parent_window.gestion_asignaturas.obtener_asignaturas()
                self.cbx_filtrar_asignatura.addItems([a.nombre for a in asignaturas])

        #funcion para mostrar un reporte de tareas por semestre
        def filtrar_por_semestre(self):
            semestre_nombre = self.cbx_filtrar_semestre.currentText()
            if not semestre_nombre:
                QMessageBox.warning(self, "Error", "Seleccione un semestre.")
                return

            try:
                tareas = self.parent_window.gestion_semestres.filtrar_tareas_por_semestre(self.parent_window.gestion_tareas.tareas, semestre_nombre)
                self.mostrar_tareas(tareas)
            except ValueError as e:
                QMessageBox.warning(self, "Error", str(e))

        #funcion para mostrar un reporte de tareas por mes
        def filtrar_por_mes(self):
            mes_nombre = self.cbx_filtrar_mes.currentText()
            if not mes_nombre:
                QMessageBox.warning(self, "Error", "Seleccione un mes.")
                return
            try:
                mes = self.meses.index(mes_nombre) + 1
                anio = datetime.now().year
                tareas = self.parent_window.gestion_tareas.filtrar_tareas_por_mes(mes, anio)
                self.mostrar_tareas(tareas)
            except ValueError:
                QMessageBox.warning(self, "Error", "El mes seleccionado no es válido.")
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Error al filtrar por mes: {e}")

        #funcion para mostrar un reporte de tareas por asignatura seleccionada
        def filtrar_por_asignatura(self):
            asignatura_nombre = self.cbx_filtrar_asignatura.currentText()
            if not asignatura_nombre:
                QMessageBox.warning(self, "Error", "Seleccione una asignatura.")
                return
            tareas = [tarea for tarea in self.parent_window.gestion_tareas.tareas if tarea.asignatura == asignatura_nombre]
            self.mostrar_tareas(tareas)

        #funcion para mostrar las tareas filtradas en la lista de tareas
        def mostrar_tareas(self, tareas):
            self.lst_TareasFiltro.clear()
            if not tareas:
                self.lst_TareasFiltro.addItem("No hay tareas para el filtro seleccionado.")
            else:
                for tarea in tareas:
                    self.lst_TareasFiltro.addItem(f"{tarea.nombre} ({tarea.fecha_entrega})")

        #funcion para guardar el reporte de las tareas filtradas en un archivo .dat
        def guardar_reporte(self):
            tareas = [self.lst_TareasFiltro.item(i).text() for i in range(self.lst_TareasFiltro.count())]

            if not tareas:
                QtWidgets.QMessageBox.warning(self, "Error", "No hay datos para guardar en el reporte.")
                return
            try:
                self.parent_window.gestion_semestres.guardar_reporte(tareas)
                QtWidgets.QMessageBox.information(self, "Éxito", "Reporte guardado en carpeta reportes")
            except Exception as e:
                QtWidgets.QMessageBox.warning(self, "Error", str(e))

    # **Ventana Notificaciones** gestiona los dias previos al envio de una notificacion por correo
    class VentanaNotificaciones(QtWidgets.QWidget, Ui_FormNotificaciones):
        def __init__(self, gestion_notificaciones, parent=None):
            super().__init__(parent)
            self.setupUi(self)
            self.gestion_notificaciones = gestion_notificaciones
            self.cbx_dias_antes.addItems(["1", "2", "3", "5", "7"])
            self.btn_guardar_notificacion.clicked.connect(self.guardar_notificacion)
            self.btn_cancelar_notificacion.clicked.connect(self.close)
            self.cbx_dias_antes.setCurrentText(str(self.gestion_notificaciones.dias_antes))

        #función para guardar la configuración de notificaciones según los días seleccionados
        def guardar_notificacion(self):
            try:
                dias_antes = int(self.cbx_dias_antes.currentText())
                #llamamos al gestor de notificaciones para programar de acuerdo a los dias seleccionados
                self.gestion_notificaciones.programar_notificaciones(dias_antes)
                QtWidgets.QMessageBox.information(self, "Configuración guardada",f"Notificaciones por email programadas {dias_antes} días antes.")
                self.close()
            except Exception as e:
                QtWidgets.QMessageBox.warning(self, "Error", f"No se pudo guardar la configuración: {e}")
