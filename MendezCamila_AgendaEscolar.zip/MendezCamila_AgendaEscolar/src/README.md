# Agenda Escolar
Una aplicación de escritorio diseñada para la gestión eficiente de tareas escolares, semestres, asignaturas y profesores. Con una interfaz gráfica intuitiva desarrollada en PyQt6, esta herramienta permite organizar y monitorear el trabajo académico de manera efectiva.

---

## Descripción General

**Agenda Escolar** ofrece las siguientes funcionalidades:
- Crear, editar y eliminar tareas.
- Filtrar tareas por semestre, mes, asignatura, prioridad o estado.
- Administrar asignaturas, profesores y semestres.
- Generar reportes personalizados en formato .dat.
- Recibir notificaciones de tareas pendientes.

La aplicación utiliza el patrón de diseño **Modelo-Vista-Controlador (MVC)** para garantizar una separación clara entre la lógica del negocio, la interfaz y la interacción del usuario.

---

## Características Principales

### **1. Gestión de Tareas**
- Creación de tareas con atributos como nombre, asignatura, prioridad, descripción y fecha de entrega.
- Edición de tareas existentes, incluyendo actualización de su estado y prioridad.
- Eliminación de tareas innecesarias.

### **2. Filtrado Avanzado**
- Filtra tareas por:
  - **Estado**: Pendiente, En progreso, Completada.
  - **Prioridad**: Alta, Media, Baja.
  - **Semestre**: Asignaturas correspondientes a un semestre específico.
  - **Mes**: Tareas programadas para un mes específico.
  - **Asignatura**: Selecciona tareas de una asignatura específica.

### **3. Reportes Personalizados**
- Genera reportes basados en los resultados filtrados.
- Los reportes se guardan en archivos .dat en la carpeta data/reportes/.

### **4. Notificaciones**
- Alertas automáticas de tareas pendientes.
- Configura días de antelación para recibir notificaciones.
- Enviar correos al crear una tarea.

### **5. Administración de Asignaturas y Profesores**
- Crea, edita y elimina asignaturas.
- Asocia asignaturas con profesores registrados.

### **6. Gestión de Semestres**
- Filtra tareas por semestre y asignatura.
- Visualiza tareas programadas en periodos específicos.

---

## Requisitos

### **Software**
- **Python**: Versión 3.9 o superior.
- **Bibliotecas necesarias**:
  - PyQt6: pip install pyqt6

### **Sistema Operativo**
- Compatible con Windows.

---

## Instalación

1. Descargar proyecto .rar y descomprimir.

---

## Uso

### **Ejecución**
1. Ejecuta el archivo principal:

   Main.py

2. La aplicación mostrará una ventana de inicio de sesión.

---
### **Orden de Ingreso de Datos**
Para garantizar el correcto funcionamiento del sistema, se recomienda seguir el siguiente orden al ingresar datos:

- **Profesores**: Accede a la ventana de Profesores y agrega todos los profesores necesarios.
- **Asignaturas**: En la ventana de Asignaturas, selecciona el profesor correspondiente y crea las asignaturas.
   	Las asignaturas creadas se sincronizan automáticamente con otras ventanas.
- **Tareas**: Ingresa a la ventana de Tareas y selecciona la asignatura correspondiente para añadir tareas.
   	Define detalles como prioridad, fecha de entrega y descripción.
- **Subtareas**: Agrega subtareas vinculadas a una tarea previamente creada. Considera que las subtareas están vinculadas al estado de la tarea principal, por 	ejemplo si existen 3 Subtareas y las 3 se marcan como completadas, el estado de la tarea principal en HistorialTareas será "completado", si solo una 	se marca como completado, el estado de la tarea principal en HistorialTareas será "en progreso" y si ninguna subtarea modifica su estado, el estado 	de la tarea principal será "pendiente".
- **Semestres**: En la ventana de Semestres, organiza las tareas en los semestres correspondientes para facilitar su seguimiento.

---
## Arquitectura del Proyecto
    src/
    controlador/
    VentanaPrincipal.py
    VentanaAsignaturas.py
    ...
    modelo/
    GestionTareas.py
    GestionAsignaturas.py
    ...
    vista/
    Ui_FormPrincipal.py
    Ui_FormAsignaturas.py
    ...
    data/
    reportes/
    reporte.dat
    Main.py

### **Patrón de Diseño**
El proyecto sigue el patrón **Modelo-Vista-Controlador (MVC)**:
- **Modelo**: Maneja la lógica del negocio y la gestión de datos.
- **Vista**: Contiene las interfaces gráficas creadas con PyQt6.
- **Controlador**: Coordina la interacción entre el modelo y la vista.

---

**No requiere plugins adicionales**

---
**Para pruebas use el usuario admin**
- **Usuario:** admin
- **Correo:** camila.mendezh@ucuenca.edu.ec
- **Contraseña:** admin


